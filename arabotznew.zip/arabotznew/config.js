{
"Lolkey": "KurrXd",
"Vhtear": "YOUR APIKEY",
"Xteam": "d90a9e986e18778b",
"Zeks": "apivinz",
"Nurutomo": "YOUR APIKEY",
"Hunter": "BELIAJASONO",
"Zero": "ZeroYT7"
}